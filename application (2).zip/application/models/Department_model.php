<?php 
class Department_model extends CI_Model
{	
	protected $table = 'departments';
	public function get_all_departments()
	{
	 $this->db->where('DeptType','Products');
     $this->db->where('published_state','yes');
     $this->db->order_by('DisplayOrder');
      return $this->db->get($this->table)->result();
	}
    public function get_department_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get($this->table)->result();
	}
	
    public function update_department_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update($this->table,$data);
	}
		function delete_department_by_id($id)
	{
		$this->db->where('id',$id);
		$this->db->delete($this->table);
	}
    public function get_all_dept()
	{
		$this->db->order_by("id");
	 return $this->db->get('departments')->result();
	}

  
	
	
}
