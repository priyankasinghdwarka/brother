<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Department extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$admin_id = $this->session->userdata('ADMIN_ID');
		$this->load->model('Department_model');
		if(empty($admin_id))
		{
			redirect('admin');
		}
		$this->load->library('form_validation');
	}
	
	public function listing()
	{
		$data['result'] = $this->Department_model->get_all_departments(); 
		$this->load->view('admin/department/listing',$data);
	}

	
	public function edit()
	{
		$args = func_get_args();
		$data['result'] = $this->Department_model->get_department_by_id($args[0]);
		if(isset($_POST['submit']))
		{
			$DeptTitle   	= $_POST['DeptTitle'];
			$DeptShortDesc	= $_POST['DeptShortDesc'];
			$DeptDescription = $_POST['DeptDescription'];
			$published_state= $_POST['published_state'];
		    $postdata = array (
                     	'DeptTitle'             => $DeptTitle,
                     	'DeptShortDesc'         => $DeptShortDesc,
                     	'DeptDescription'       => $DeptDescription,
		                'published_state'      => $published_state
		         );

				$this->Department_model->update_department_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">Record has been successfully updated.</div>');
				redirect('admin/department/listing');
	
		
		}
	
	$data['department'] = $this->Department_model->get_all_dept();
	$this->load->view('admin/department/edit',$data);
	}

public function delete()
	{
		$args = func_get_args();
		$team_data =  $this->Department_model->get_department_by_id($args[0]);
		$this->Department_model->delete_department_by_id($args[0]);
	    $this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully deleted.</div>');
		redirect('admin/department/listing');
	}
	
	
		
}
