<!doctype html>
<html>
   <head>
   <?php $this->load->view('front/layout/head'); ?>
   </head>
   <body>
      <?php $this->load->view('front/layout/header'); ?>
      <!-- Side bar --->
      <div id="mySidenav" class="sidenav">
         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
         <div class="cart-item-wraper">
            <div class="shopping-cart-header">
               <i class="fa fa-shopping-cart cart-icon"></i><span class="badge">3</span>
               <div class="shopping-cart-total">
                  <span class="lighter-text">Total:</span>
                  <span class="main-color-text">$2,229.97</span>
               </div>
            </div>
            <ul>
               <!-- First Item -->
               <li>
                  <div class="photo">
                     <img src="<?php echo base_url('assets/front/'); ?>images/product-1.jpg">
                  </div>
                  <div class="item-details">
                     <strong>Tables</strong>
                     <span>$849.99</span>
                     <span> Qty: 01</span>
                     <a href="javascript:void(0)"><i class="fa fa-trash"></i></a>
                  </div>
               </li>
               <!-- First Item  End-->
               <!-- First Item -->
               <li>
                  <div class="photo">
                     <img src="<?php echo base_url('assets/front/'); ?>images/product-1.jpg">
                  </div>
                  <div class="item-details">
                     <strong>Tables</strong>
                     <span>$849.99</span>
                     <span>Qty: 01</span>
                     <a href="javascript:void(0)"><i class="fa fa-trash"></i></a>
                  </div>
               </li>
               <!-- First Item  End-->
            </ul>
            <div class="checkoutbtn">
               <a href="#" class="btn side-checkout">Checkout</a>
            </div>
         </div>
      </div>
      <!-- Sidebar --->
        <!-- Slider  --->
    <div class="main-slider">
<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
  </ul>
  <div class="main-slider">
<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="<?php echo base_url('assets/front/'); ?>images/slide-1.jpg">
      <div class="container">
           <div class="carousel-caption">
            <h3><?php echo $banner[0]->title ;?></h3>
            <p><?php echo $banner[0]->description ;?></p>
           </div>
      </div>
    </div>
   
       <div class="carousel-item">
        <img src="<?php echo base_url('assets/front/'); ?>images/slide-1.jpg">
      <div class="container">
           <div class="carousel-caption">
            <h3><?php echo $banner[1]->title ;?></h3>
            <p><?php echo $banner[1]->description ;?></p>
           </div>
      </div>
    </div>

  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
</div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
</div>
      <section class="feature">
         <div class="container">
            <!-- <div class="heading-section">
               <h1><?php echo $feature[0]->title?></h1>
               <p><?php echo $feature[0]->description?>
               </p>
            </div> -->
            <div class="heading-section">
               <h1><?php echo $feature[0]->title?></h1>
               <p>Friedman Brothers has been the World's premier creator of
                  custom handcrafted <br/>decorative wall art for elegant interior design
               </p>
            </div>
            <div class="icon-box">
               <div class="row">
                  <?php foreach($icons as $row){ ?>
                  <div class="col-md-6  col-lg-3">
                     <div class="icon-wraper">
                        <div class="icon-left">
                           <img src="<?php echo base_url('assets/front/'); ?>images/<?php echo $row->image;?>"/>
                        </div>
                        <div class="icon-text">
                           <h5><?php echo $row->title;?></h5>
                           <p><?php echo $row->description;?></p>
                        </div>
                     </div>
                  </div>
               <?php }?>
                  <!-- Col -->
                
                  <!-- Col -->
                
                  <!-- Col -->
                 
                  <!-- Col -->
               </div>
            </div>
            <!-- Icon End --->
            <!--- two img -->
            <div class="two-img">
               <div class="row">
                  <div class="col-md-4">
                     <div class="box-img">
                        <img src="<?php echo base_url('assets/front/'); ?>images/left-img.jpg">
                        <div class="overlay-text">
                           <h3><?php echo $collection[0]->cat_name?></h3>
                           <p><?php echo $collection[0]->cat_desc?></p>
                           <a href="<?php echo $collection[0]->url_link?>"><i class="fa fa-angle-right"></i></a>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-8">
                     <div class="box-img">
                        <img src="<?php echo base_url('assets/front/'); ?>images/<?php echo $collection[1]->image?>">
                        <div class="overlay-text">
                           <h3><?php echo $collection[1]->cat_name?></h3>
                           <p><?php echo $collection[1]->cat_desc?></p>
                           <a href="<?php echo $collection[1]->url_link?>"><i class="fa fa-angle-right"></i></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- End Two --->
            <!-- Four Columns ---->
            <div class="four-cols">
               <div class="row">
                  <div class="col-md-6  col-lg-3">
                     <div class="box-four">
                        <img src="<?php echo base_url('assets/front/'); ?>images/<?php echo $collection[2]->image?>">
                        <div class="overlay-text">
                           <h3><?php echo $collection[2]->cat_name?></h3>
                           <p><?php echo $collection[2]->cat_desc?></p>
                           <a href="<?php echo $collection[2]->url_link?>"><i class="fa fa-angle-right"></i></a>
                        </div>
                     </div>
                  </div>
                  <!-- Column One -->
                  <div class="col-md-6  col-lg-3">
                     <div class="box-four">
                        <img src="<?php echo base_url('assets/front/'); ?>images/<?php echo $collection[3]->image?>">
                        <div class="overlay-text">
                           <h3><?php echo $collection[3]->cat_name?></h3>
                           <p><?php echo $collection[3]->cat_desc?></p>
                           <a href="<?php echo base_url('products/window-hardware-window-hardware?deptid=8&cat_id=1192'); ?>"><i class="fa fa-angle-right"></i></a>
                          
                        </div>
                     </div>
                  </div>
                  <!-- Column One -->
                  <div class="col-md-6  col-lg-3">
                     <div class="box-four">
                        <img src="<?php echo base_url('assets/front/'); ?>images/<?php echo $collection[4]->image?>">
                        <div class="overlay-text">
                         <h3><?php echo $collection[4]->cat_name?></h3>
                           <p><?php echo $collection[4]->cat_desc?></p>
                           <a href="<?php echo base_url('products/sconces?deptid=3'); ?>"><i class="fa fa-angle-right"></i></a>
                        </div>
                     </div>
                  </div>
                  <!-- Column One -->
                  <div class="col-md-6  col-lg-3">
                     <div class="box-four">
                        <img src="<?php echo base_url('assets/front/'); ?>images/<?php echo $collection[5]->image?>">
                        <div class="overlay-text">
                           <h3><?php echo $collection[5]->cat_name?></h3>
                           <p><?php echo $collection[5]->cat_desc?></p>
                           <a href="<?php echo base_url('products/more-brackets?deptid=8&cat_id=1068'); ?>"><i class="fa fa-angle-right"></i></a>
                        </div>
                     </div>
                  </div>
                  <!-- Column One -->
               </div>
            </div>
            <!-- End Four -->
         </div>
      </section>
      <section class="most-selling">
         <div class="container">
            <div class="heading-section">
               <h1>Most Selling Products</h1>
               <p>Friedman Brothers has been the World's premier creator of custom handcrafted <br>
                  decorative wall art for elegant interior design
               </p>
            </div>
            <div class="product-wrapper">
               <div class="row">

                  <?php foreach($result as $row){?>
                  <div class="col-md-6  col-lg-3">
                     <div class="main-box">
                        <div class="img-wrap">
                               <?php $default_r_img = $this->front_model->get_default_image($row->id);
                                   if(count($default_r_img)>0){
                                   $imgpath = base_url().choose_image_size($default_r_img[0]->img_path,"thumb");
                                   $large_image = base_url().choose_image_size($default_r_img[0]->img_path,"large");
                                 }else{ $large_image = ''; }
                             ?>
                           <a href="<?php echo base_url('product-detail/'.create_slug($row->ProdTitle.$row->Sku).'?pid='.$row->id); ?>"><img src="<?php echo str_replace('_sm','_lg',$large_image); ?>"></a>
                           <div class="hoverbox">
                              <a href="<?php echo base_url('product-detail/'.create_slug($row->ProdTitle.$row->Sku).'?pid='.$row->id); ?>" class="view-prod">View Product</a>
            <button type="button"  class="wishilist" title=" Add to Wishlist" data_id="<?php echo $row->id; ?>"><i class="fa fa-heart"></i></button> 

                             
                             <!-- <a href="#" class="wishilist"><i class="fa fa-heart"></i></a>-->
                           </div>
                        </div>
                        <div class="description">
                           <span><?php echo $row->ProdTitle ?></span>
                           <small>Style#: <?php echo $row->Sku?></small>
                        </div>
                     </div>
                  </div>
               <?php }?>
                  <!-- Column-1 -->
                 
                  <!-- Column-1 -->
              
                  <!-- Column-1 -->
                
                  <!-- Column-1 -->
              
                  <!-- Column-1 -->
                
                  <!-- Column-1 -->
              
                  <!-- Column-1 -->
               
                  <!-- Column-1 -->
               </div>
               <!-- Row End --->
            </div>
            <!-- Product Wrapper --->
            <!-- About Brothers -->

            <div class="about-brother">
               <h2><?php echo $about[0]->title?></h2>
               <p><?php echo $about[0]->description?>
               </p>
            </div>
         </div>
      </section>
      <section class="testimonials">
         <div class="container">
            <div class="heading-section">
               <h1>Client Testimonials</h1>
            </div>
            <div class="owl-carousel owl-testimonial">
         <?php foreach($testimonial as $row){?>
               <div class="item">
                  <div class="client-quotes">
                     <p><?php echo $row->description;?>
                     </p>
                  </div>
                  <div class="author-info">
                     <div class="client-pic">
                        <img src="<?php echo base_url('assets/front/'); ?>images/<?php echo $row->image;?>">
                     </div>
                     <div class="client-name">
                        <strong><?php echo $row->customer_name;?></strong>
                        <span><?php echo $row->customer_desc;?></span>
                     </div>
                  </div>
               </div>
         <?php }?>
            </div>
         </div>
      </section>    
      <?php $this->load->view('front/layout/footer'); ?>
   </body>
</html>
<script type="text/javascript">
$(".wishilist").click(function(){
      var prodid = $(this).attr("data_id");
    //  alert(prodid);
      var wurl = '<?php echo base_url('wishlist');?>';
      $.ajax({
        url:wurl,
        type:'POST',
        dataType:'json',
        data:{"prodid":prodid},
        success: function(data){
       
         if(data=="2"){
           
          window.location.replace("<?php echo base_url('User/login');?>");
         }else{
            
          alert("Added To Wishlist");
         }

      }
    });
    });
</script>