<?php 
class Home_model extends CI_Model
{	
	protected $table = 'tbl_collection';
   /*-----------------------  Collection Query Start Here-----------------------*/ 
	public function get_all_collection()
	{
		return $this->db->get($this->table)->result();
	}
	public function get_collection_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get($this->table)->result();
	}
	public function update_collection_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update($this->table,$data);
	}
	/*-----------------------  Banner Query Start Here---------------------------*/
	public function get_all_banner()
	{
		return $this->db->get('tbl_banner')->result();
	}
	public function get_banner_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('tbl_banner')->result();
	}
	public function update_banner_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('tbl_banner',$data);
	}
	/*-----------------------  Feature Query Start Here-----------------------------*/
	public function get_all_feature()
	{
		return $this->db->get('tbl_feature')->result();
	}
	public function get_feature_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('tbl_feature')->result();
	}
	public function update_feature_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('tbl_feature',$data);
	}
	/*-----------------------  Icons Query Start Here-----------------------------*/
	public function get_all_icons()
	{
		return $this->db->get('tbl_icons')->result();
	}
	public function get_icons_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('tbl_icons')->result();
	}
	public function update_icons_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('tbl_icons',$data);
	}
	/*-----------------------  About Query Start Here-----------------------------*/
	public function get_all_about()
	{
		return $this->db->get('tbl_about')->result();
	}
	public function get_about_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('tbl_about')->result();
	}
	public function update_about_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('tbl_about',$data);
	}
		/*-----------------------  Top Query Start Here-----------------------------*/
	public function get_all_top()
	{
		return $this->db->get('tbl_top')->result();
	}
	public function get_top_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('tbl_top')->result();
	}
	public function update_top_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('tbl_top',$data);
	}
	
	
	

}
