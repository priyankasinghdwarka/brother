<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home  extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$admin_id = $this->session->userdata('ADMIN_ID');
		if(empty($admin_id))
		{
			redirect('admin');
		}
		$this->load->library('form_validation');
		$this->load->model('Home_model');
         }
/*-----------------------  Collection Query Start Here-----------------------*/	
	public function listing()
	{
		$data['result'] = $this->Home_model->get_all_collection(); 
		$this->load->view('admin/home/listing',$data);
	}
		
public function edit()
	{
		$args = func_get_args();
		$data['result'] = $this->Home_model->get_collection_by_id($args[0]); 
		
		if(isset($_POST['submitform']))
		{
			$postdata = $this->input->post();
				
			if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
				{
					$allow_ext = array('png','jpg','jpeg','JPEG','gif');
					$file_ext = image_extension($_FILES['image']['name']);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name']);
						$tmp_name = $_FILES['image']['tmp_name'];
						$path = 'assets/front/images/'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$postdata['image'] = $file_name;	
						//delete_file('uploads/cms/',$postdata['old_file']);
					}
				}
				
				
				unset($postdata['submitform']);
				$this->Home_model->update_collection_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully updated.</div>');
				redirect('admin/home/listing');	
			}
        $this->load->view('admin/home/edit',$data);
	}

/*-----------------------  Banner Query Start Here---------------------------*/
  public function banner()
	{
		$data['result'] = $this->Home_model->get_all_banner(); 
		$this->load->view('admin/banner/listing',$data);
	}

	public function edit_banner()
	{
		$args = func_get_args();
		$data['result'] = $this->Home_model->get_banner_by_id($args[0]); 
		
		if(isset($_POST['submitform']))
		{
			$postdata = $this->input->post();
				
			if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
				{
					$allow_ext = array('png','jpg','jpeg','JPEG','gif');
					$file_ext = image_extension($_FILES['image']['name']);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name']);
						$tmp_name = $_FILES['image']['tmp_name'];
						$path = 'assets/front/images/'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$postdata['image'] = $file_name;	
					}
				}
				unset($postdata['submitform']);
				$this->Home_model->update_banner_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully updated.</div>');
				redirect('admin/home/banner');
			}
		$this->load->view('admin/banner/edit',$data);
	}
/*-----------------------  Feature Query Start Here-----------------------------*/
 public function feature()
	{
		$data['result'] = $this->Home_model->get_all_feature(); 
		$this->load->view('admin/feature/listing',$data);
	}

	public function edit_feature()
	{
		$args = func_get_args();
		$data['result'] = $this->Home_model->get_feature_by_id($args[0]); 
		
		if(isset($_POST['submitform']))
		{
			$postdata = $this->input->post();
				
			if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
				{
					$allow_ext = array('png','jpg','jpeg','JPEG','gif');
					$file_ext = image_extension($_FILES['image']['name']);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name']);
						$tmp_name = $_FILES['image']['tmp_name'];
						$path = 'assets/front/images/'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$postdata['image'] = $file_name;	
					}
				}
				unset($postdata['submitform']);
				$this->Home_model->update_feature_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully updated.</div>');
				redirect('admin/home/feature');				
			
		}
		
		$this->load->view('admin/feature/edit',$data);
	}
/*-----------------------  Icons Query Start Here-----------------------------*/
 public function icons()
	{
		$data['result'] = $this->Home_model->get_all_icons(); 
		$this->load->view('admin/icons/listing',$data);
	}

	public function edit_icons()
	{
		$args = func_get_args();
		$data['result'] = $this->Home_model->get_icons_by_id($args[0]); 
		
		if(isset($_POST['submitform']))
		{
			$postdata = $this->input->post();
				
			if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
				{
					$allow_ext = array('png','jpg','jpeg','JPEG','gif');
					$file_ext = image_extension($_FILES['image']['name']);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name']);
						$tmp_name = $_FILES['image']['tmp_name'];
						$path = 'assets/front/images/'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$postdata['image'] = $file_name;	
					}
				}
				unset($postdata['submitform']);
				$this->Home_model->update_icons_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully updated.</div>');
				redirect('admin/home/icons');				
			
		}
		
		$this->load->view('admin/icons/edit',$data);
	}
/*-----------------------  Icons Query Start Here-----------------------------*/
 public function about()
	{
		$data['result'] = $this->Home_model->get_all_about(); 
		$this->load->view('admin/about/listing',$data);
	}

	public function edit_about()
	{
		$args = func_get_args();
		$data['result'] = $this->Home_model->get_about_by_id($args[0]); 
		
		if(isset($_POST['submitform']))
		{
			$postdata = $this->input->post();
				
			if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
				{
					$allow_ext = array('png','jpg','jpeg','JPEG','gif');
					$file_ext = image_extension($_FILES['image']['name']);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name']);
						$tmp_name = $_FILES['image']['tmp_name'];
						$path = 'assets/front/images/'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$postdata['image'] = $file_name;	
					}
				}
				unset($postdata['submitform']);
				$this->Home_model->update_about_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully updated.</div>');
				redirect('admin/home/about');				
			
		}
		
		$this->load->view('admin/about/edit',$data);
	}
	/*-----------------------  Top Query Start Here-----------------------------*/
 public function top()
	{
		$data['result'] = $this->Home_model->get_all_top(); 
		$this->load->view('admin/top/listing',$data);
	}

	public function edit_top()
	{
		$args = func_get_args();
		$data['result'] = $this->Home_model->get_top_by_id($args[0]); 
		
		if(isset($_POST['submitform']))
		{
			$postdata = $this->input->post();
			unset($postdata['submitform']);
				$this->Home_model->update_top_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully updated.</div>');
				redirect('admin/home/top');				
			
		}
		
		$this->load->view('admin/top/edit',$data);
	}	
	
}