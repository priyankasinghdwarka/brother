<?php //print_r($product); ?>
<!doctype html>
<html>
   <head>
      <?php $this->load->view('front/layout/head'); ?>
      <link href="<?php echo base_url('assets/front/css/jquery.exzoom.css'); ?>" rel="stylesheet" type="text/css"/>
      <style type="text/css">
         #share-buttons img {
         width: 35px;
         padding: 5px;
         border: 0;
         box-shadow: 0;
         display: inline;
         }
      </style>
      <script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5c00cc100624ce0011ee8788&product=inline-share-buttons' async='async'></script>
      <style>
         .drop {
         position: relative;
         }
         .drop .social-media {
         position: absolute;
         top: 100%;
         min-width: 200px;
         display: none;
         transition: all 500ms ease;
         }
         .drop .social-media a {
         display: inline-block;
         background: #171771;
         width: 32px;
         text-align: center;
         color: #fff;
         }
         .drop:hover .social-media {
         display: block;
         }
         /* Pop Up */
.modal.show .custom-modal {
    min-width: auto;
}

.custom-pop {
    max-width: 400px;
    width: 100%;
    margin: 0 auto;
    padding: 30px;
}
.custom-pop button.close {
    padding: 0;
    background: #171771;
    background-color: transparent;
    border: 0;
    -webkit-appearance: none;
    position: absolute;
    right: 0;
    top: 0;
    width: 32px;
    color: #171771;
    height: 32px;
    opacity: 1;
    display: block;
    z-index: 9999;
}
.custom-pop .close {
    float: right;
    font-size: 1.5rem;
    font-weight: 700;
    line-height: 1;
    color: #000;
    text-shadow: 0 1px 0 #fff;
    opacity: .5;
    background: #171771 !important;
    color: #fff !important;
}

.custom-pop .modal-title {
    text-align: center;
    font-weight: 600;
    text-transform: uppercase;
}
      </style>
      <style>
         .select-frame-wrap img:hover{border: 3px solid #171771;}
         .img_act{border: 3px solid #171771;}
      </style>
   </head>
   <!-----------------End by priyanka on 1dec for social share -------------------->
   <body>
      <?php $this->load->view('front/layout/header'); ?>
      <!-- Breadcrumb --->
      <div class="page-title">
         <div class="container">
            <h4>Product Detail</h4>
            <ol class="breadcrumb">
               <li class="breadcrumb-item"><a href="#">Home</a></li>
               <li class="breadcrumb-item active" aria-current="page">Product Detail</li>
            </ol>
         </div>
      </div>
      <!---  Main Inner Wrapper --->
      <?php $related_img = $this->front_model->get_related_images($_GET['pid']); ?>
      <?php $default_img = $this->front_model->get_default_image($_GET['pid']); ?>
      <div class="wraper-main-inner">
         <div class="container" id="invoice_print">
            <div class="row">
               <div class="col-xl-5">
                  <div class="preview-product">
                     <div class="exzoom hidden" id="exzoom">
                        <div class="exzoom_img_box">
                           <ul class='exzoom_img_ul'>
                              <?php if(count($default_img)>0){ ?>
                              <?php foreach($default_img as $d_img)
                                 {
                                   $imgpath = base_url().choose_image_size($d_img->img_path,"thumb");
                                   $large_image = base_url().choose_image_size($d_img->img_path,"large");
                                   ?>
                              <li><img src="<?php echo str_replace('_sm','_lg',$large_image); ?>"/></li>
                              <?php } ?>
                              <?php } ?>
                              <?php if(count($related_img)>0){ ?>
                              <?php foreach($related_img as $r_img)
                                 {
                                   $imgpath = base_url().choose_image_size($r_img->img_path,"thumb");
                                   $large_image = base_url().choose_image_size($r_img->img_path,"large");
                                   ?>
                              <li><img src="<?php echo str_replace('_sm','_lg',$large_image); ?>"/></li>
                              <?php } ?>
                              <?php } ?>
                           </ul>
                        </div>
                        <div class="exzoom_nav"></div>
                        <p class="exzoom_btn">
                           <a href="javascript:void(0);" class="exzoom_prev_btn"> < </a>
                           <a href="javascript:void(0);" class="exzoom_next_btn"> > </a>
                        </p>
                     </div>
                  </div>
                  <!----  Added By priyanka on 1 dec for social share  (Start from here)---->
                  <div class="share">
                     <ul class="list-inline">
                        <li class="list-inline-item drop">
                           <i class="fa fa-share-alt"></i> <a href="#"> Social Share </a>
                           <div class="social-media">
                              <a href="http://www.facebook.com/sharer.php?u=http://graphicsmerlin.in/bro/product-detail/<?php echo $product[0]->Sku ?>?pid=<?php echo $product[0]->id ?>" target="_blank"><i class="fa fa-facebook" ></i></a>
                              <a href="https://twitter.com/share?url=http://graphicsmerlin.in/bro/product-detail/<?php echo $product[0]->Sku ?>?pid=<?php echo $product[0]->id ?>&amp;text=<?php echo $product[0]->ProdTitle.'  Style-'.$product[0]->Sku; ?>&amp;hashtags=simplesharebuttons" target="_blank"><i class="fa fa-twitter"></i></a>
                              <!-- <a href="http://www.linkedin.com/shareArticle?mini=true&url=http://graphicsmerlin.in/bro/product-detail/<?php echo $product[0]->Sku ?>?pid=<?php echo $product[0]->id ?>"><i class="fa fa-linkedin"></i></a>-->
                              <a href="https://plus.google.com/share?url=http://graphicsmerlin.in/bro/product-detail/<?php echo $product[0]->Sku ?>?pid=<?php echo $product[0]->id ?>" target="_blank"><i class="fa fa-google-plus"></i></a>
                           </div>
                        </li>
                        <li class="list-inline-item" id="print_btn" onclick="return print_invoice('invoice_print');"> <i class="fa fa-print"></i> <a href="#"> Print This </a></li>
                     </ul>
                     <!----  By priyanka on 1 dec for social share  (End here)---->
                  </div>
               </div>
               <!-- Column One End -->
               <div class="col-xl-7">
                  <div class="product-details-view">
                     <div class="title-single">
                        <?php echo $product[0]->ProdTitle; ?>
                     </div>
                     <div class="sub-title">
                        Style#: <?php echo $product[0]->Sku; ?>
                     </div>
                     <div class="single-description" id="content">
                        <h6>Description:</h6>
                        <?php echo $product[0]->ProdDescription; ?><br><br>
                        <?php $available_size = $this->front_model->get_product_size($_GET['pid']); ?>
                        <?php
                           if(!isset($_GET['sizeid']) && empty($_GET['sizeid'])  || $_GET['sizeid']=='custom')
                           {
                                $s_id = $available_size[0]->id;
                           }
                           else
                           {
                                $s_id = $_GET['sizeid'];
                           }
                           ?>
                        <?php $available_comp = $this->front_model->get_comp_sets($_GET['pid']); ?>
                        <?php $comps_row = $this->front_model->get_comp_rows($s_id,$available_comp[0]->id); ?>
                        <?php  $finish_title = $this->front_model->get_comp_popular_finishes($comps_row[0]->compid); ?>
                        <form class="tab-form" method="get" action="#content">
                           <input type='hidden' name="pid" value="<?php echo $_GET['pid']; ?>">
                           <div class="nav nav-tabs nav-justified" id="nav-tab" role="tablist">
                              <a class="nav-item nav-link active tab1" id="nav-home-tab" data-toggle="tab" href="#nav-1" role="tab" aria-controls="nav-1" aria-selected="true"><?php echo $available_comp[0]->menu_title; ?></a>
                              <a class="nav-item nav-link tab2" id="nav-profile-tab" data-toggle="tab" href="#nav-2" role="tab" aria-controls="nav-2" aria-selected="false"><?php echo $finish_title[0]->name; ?></a>
                              <?php if(count($available_comp)>1){ ?>
                              <a class="nav-item nav-link tab3" id="nav-profile-tab" data-toggle="tab" href="#nav-3" role="tab" aria-controls="nav-3" aria-selected="false">Select Mirror Finish</a>
                              <?php } ?>
                           </div>
                           <div class="tab-content" id="nav-tabContent">
                              <div class="tab-pane fade show active" id="nav-1" role="tabpanel" aria-labelledby="nav-home-tab">
                                 <div class="form-inner-tab">
                                    <div class="row">
                                       <select class="size size_one" name='sizeid' required>
                                          <?php if(count($available_size)>0){ ?>
                                          <?php foreach($available_size as $size){ ?>
                                          <?php
                                             $w = format_fractions(roundUp($size->width, 4));
                                             $h = format_fractions(roundUp($size->height, 4));
                                             $d = ($size->depth=='')?'':format_fractions(roundUp($size->depth, 0));
                                             ?>
                                          <option <?php echo (isset($_GET['sizeid']) && $_GET['sizeid']==$size->id )?'selected':''; ?> value="<?php echo $size->id; ?>"><b><?php echo $size->size_code; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $w; ?>"w  x  <?php echo $h; ?>"h <?php echo(!empty($d))?' x '.$d.'"d':''; ?></option>
                                          <?php } ?>
                                          <option <?php echo (isset($_GET['sizeid']) && $_GET['sizeid']=='custom' )?'selected':''; ?> value='custom'>Custom</option>
                                          <?php } ?>
                                       </select>
                                       <span class="custom_options_data" style="width: 100%; display:none;">
                                          <select class="custom-w" name='w'>
                                             <option value="">Width</option>
                                             <?php for($i=1; $i<=50; $i++){ ?>
                                             <option value="<?php echo $i; ?>" <?php echo (isset($_GET['w']) && $_GET['w']==$i )?'selected':''; ?>><?php echo $i; ?></option>
                                             <?php } ?>
                                          </select>
                                          <?php
                                             if(empty($d)){ $l_class = 'c_w'; }else{ $l_class=''; }
                                             ?>
                                          <select class="custom-w <?php echo $l_class; ?>" name='h'>
                                             <option value="">Height</option>
                                             <?php for($j=1; $j<=50; $j++){ ?>
                                             <option value="<?php echo $j; ?>" <?php echo (isset($_GET['h']) && $_GET['h']==$j )?'selected':''; ?>><?php echo $j; ?></option>
                                             <?php } ?>
                                          </select>
                                          <?php if(!empty($d)){ ?>
                                          <select class="custom-w c_w" name='d'>
                                             <option value="">Depth</option>
                                             <?php for($k=1; $k<=50; $k++){ ?>
                                             <option value="<?php echo $k; ?>" <?php echo (isset($_GET['d']) && $_GET['d']==$k )?'selected':''; ?>><?php echo $k; ?></option>
                                             <?php } ?>
                                          </select>
                                          <?php } ?>
                                       </span>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade show" id="nav-2" role="tabpanel" aria-labelledby="nav-home-tab">
                                 <div class="form-inner-tab">
                                    <div class="row">
                                       <?php
                                          if(count($finish_title)>0)
                                          {
                                            $finish_ids= $this->front_model->get_comp_group_pop_fids($finish_title[0]->id);
                                            $l=0; foreach($finish_ids as $fids)
                                            { $l++;
                                              $finish_data= $this->front_model->get_product_by_id($fids);
                                          ?>
                                       <?php if(count($finish_data)>0){ ?>
                                       <div class="col-md-3 col-sm-6 col-xs-6 finish_class">
                                          <div class="select-frame-wrap" style="max-height: none;">
                                             <label for="finish-<?php echo $finish_data[0]->id; ?>"><img src="<?php echo base_url('data'.$finish_data[0]->ProdIcon); ?>" class='finish_img1 img_<?php echo $finish_title[0]->id; ?>' img_cls='img_<?php echo $finish_title[0]->id; ?>'></label>
                                          </div>
                                       </div>
                                       <input type="radio" name='finishdata-<?php echo $finish_data[0]->id; ?>' class='finishclass' value='<?php echo $finish_data[0]->id; ?>'  id='finish-<?php echo $finish_data[0]->id; ?>' style='display:none'>
                                       <?php } ?>
                                       <?php
                                          }
                                          }  ?>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade show" id="nav-3" role="tabpanel" aria-labelledby="nav-home-tab">
                                 <div class="form-inner-tab">
                                    <div class="row">
                                       <div class="select-mirror-finish">
                                          <div class="wrap-mirror-select">
                                             <?php if(count($available_comp)>0){ ?>
                                             <?php $a = 0; foreach($available_comp as $comp){ $a++; ?>
                                             <?php if($a>1){ ?>
                                             <?php $comps_row = $this->front_model->get_comp_rows($s_id,$comp->id); ?>
                                             <div class="select-drop">
                                                <label><?php echo $comp->menu_title; ?></label>
                                                <?php if(count($comps_row)>0){ ?>
                                                <select class="size " name='comprow-<?php echo $a; ?>'>
                                                   <?php if(count($comps_row)>0){ ?>
                                                   <option value="">Select Options</option>
                                                   <?php foreach($comps_row as $comp_opt){ ?>
                                                   <?php $op_t = $this->front_model->get_option_title($comp_opt->compid); ?>
                                                   <option value="<?php echo $comp_opt->id; ?>"><?php echo $op_t[0]->menu_title; ?></option>
                                                   <?php } ?>
                                                   <?php } ?>
                                                </select>
                                                <?php } ?>
                                             </div>
                                             <?php  $finish_title = $this->front_model->get_comp_popular_finishes($comps_row[0]->compid); ?>
                                             <div class="row_">
                                                <?php if(count($finish_title)>0){ ?>
                                                <?php $finish_ids= $this->front_model->get_comp_group_pop_fids($finish_title[0]->id); ?>
                                                <div class="tab-pane" id="nav-1<?php echo $comp->id; ?>" role="tabpanel" aria-labelledby="nav-profile-tab">
                                                   <div class="select-frame-finish">
                                                      <div class="row">
                                                         <?php foreach($finish_ids as $fids){ ?>
                                                         <?php $finish_data= $this->front_model->get_product_by_id($fids); ?>
                                                         <?php if(count($finish_data)>0){ ?>
                                                         <div class="col-md-3 col-sm-6 col-xs-6">
                                                            <div class="select-frame-wrap img_<?php echo $finish_data[0]->id; ?>" style="max-height: none;">
                                                               <label for="finish-"><img src="<?php echo base_url('data'.$finish_data[0]->ProdIcon); ?>" class='finish_img img_<?php echo $finish_title[0]->id; ?>' img_cls='img_<?php echo $finish_title[0]->id; ?>'></label>
                                                            </div>
                                                         </div>
                                                         <input type="radio" name='finishdata-' class='finishclass' value='<?php echo $finish_data[0]->id; ?>'  id='finish-<?php echo $finish_title[0]->id; ?>'  style='display:none'>
                                                         <?php } ?>
                                                         <?php } ?>
                                                      </div>
                                                   </div>
                                                </div>
                                                <?php } ?>
                                             </div>
                                             <?php }}} ?>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </form>
                        </br>
                        <!-- After login Section  --->
                        <div class="after-login">
                           <div class="all-option"><strong>Note: </strong> All options must be selected before creating quote.</div>
                           <?php $user_id = $this->session->userdata('USER_ID'); ?>
                           <?php if(empty($user_id)){ ?>
                           <div class="quotingfor"><a href="<?php echo base_url('user/login'); ?>" class="login-single" data-toggle="modal" data-target="#popup">Login</a> <span class="save-quotes">to Save Quotes and Other Actions.</span></div>
                           <?php }else{ ?>
                           <div class="quotingfor">
                              <strong>Quoting For:</strong> <?php echo $this->session->userdata('USER_NAME'); ?>
                              <div class="row enter-password">
                                 <div class="col-sm-6">
                                    <label><strong>Quantity</strong></label>
                                    <select class="each-size" name='qty'>
                                       <option value="50">10</option>
                                       <option value="100">100</option>
                                       <option value="150">150</option>
                                       <option value="200">200</option>
                                    </select>
                                 </div>
                                 <div class="col-sm-12">
                                    <textarea name="addquote" placeholder="Add Notes Here. Special Requests May Require Quote Adjustments." rows="5"></textarea>
                                 </div>
                                 <div class="col-sm-6">
                                    <input type="submit" name="order" value="Order Now" >
                                 </div>
                              </div>
                           </div>
                           <?php } ?>
                        </div>
                        <!-- After login End --->
                     </div>
                  </div>
               </div>
            </div>
            <!-- Row End --->
         </div>
      </div>
      <!-- End -->
      <!--Login Modal -->
      <div class="modal fade" id="popup" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
         <div class="modal-dialog modal-dialog-centered custom-modal" role="document">
            <div class="modal-content custom-pop">
               <h5 class="modal-title" id="exampleModalCenterTitle">Login Here </h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
               <div class="modal-body">
                  <div class="login-modal">
                     <form method="post">
                        <div class="form-group">
                           <input type="email" name="email" class="style-input" placeholder="Username or Email">
                        </div>
                        <div class="form-group">
                           <input type="password" name="pwd" class="style-input" placeholder="Password">
                        </div>
                        <div class="form-group">
                           <label>
                           <input type="checkbox" name="check"> <span class="style-bg"> Remember Me </span> </label>
                        </div>
                        <div class="form-group">
                           <input type="submit" name="check" class="style-input submit-style" value="Login Now">
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!--Login Modal -->
      <?php $related_products = $this->front_model->get_related_products($product[0]->Sku); ?>
      <?php if(count($related_products)>0){ ?>
      <section class="may-also">
         <div class="container">
            <div class="also-like">
               <div class="title-single">You May Also Like:</div>
               <div class="row">
                  <?php //print_r($related_products); ?>
                  <?php foreach($related_products as $r_l){ ?>
                  <?php $r_pro = $this->front_model->get_product_by_sku($r_l->RelatedSku); ?>
                  <?php if(count($r_pro)>0){ ?>
                  <?php $default_r_img = $this->front_model->get_default_image($r_pro[0]->id);
                     if(count($default_r_img)>0)
                     {
                       $imgpath = base_url().choose_image_size($default_r_img[0]->img_path,"thumb");
                       $large_image = base_url().choose_image_size($default_r_img[0]->img_path,"large");
                     }else
                     {
                        $large_image = base_url().'data'.$r_pro[0]->ProdIcon;
                     }
                     ?>
                  <div class="col-lg-2 col-md-4">
                     <a href="<?php echo base_url('product-detail/'.create_slug($r_pro[0]->ProdTitle.$r_pro[0]->Sku).'?pid='.$r_pro[0]->id); ?>" >
                     <div class="img-like-wrap">
                        <img src="<?php echo str_replace('_sm','_lg',$large_image); ?>" />
                     </div>
                     <div class="short-desc">
                        <strong><?php echo $r_pro[0]->ProdTitle; ?></strong>
                        <span>Style #<?php echo $r_pro[0]->Sku; ?></span>
                     </div>
                  </div>
                  <?php } ?>
                  <?php } ?>
               </div>
            </div>
         </div>
      </section>
      <?php } ?>
      <!-- End -->
      <?php $this->load->view('front/layout/footer'); ?>
      <script src="<?php echo base_url('assets/front/js/jquery.exzoom.js'); ?>"></script>
      <script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
      <script type="text/javascript">
         $('.preview-product').imagesLoaded( function() {
         $("#exzoom").exzoom({
             autoPlay: false,
         });
         $("#exzoom").removeClass('hidden')
         });

         $(document).ready(function(){


         $('.c_w').change(function(){
         var s_val = $(this).val();
         if(s_val!='')
         {
         setTimeout( function(){  $('.tab2').click();}  , .10000 );
         }
         });


            $('.size_one').change(function(){
                var s_val = $(this).val();
                if(s_val=='custom')
                {
                    //$('.tab-form').submit();
                    $('.custom_options_data').css("display", "flex");
                }
                else
                {
                    $('.custom_options_data').css("display", "none");
                    setTimeout( function(){  $('.tab2').click();}  , .10000 );
                }
            });

            $(".finishclass").change(function(){
                //$('.tab-form').submit();
            });

            $('.finish_img1').click(function(){
              var img_attr = $(this).attr('img_cls');
              $('.'+img_attr).removeClass('img_act');
              $(this).addClass('img_act');
              setTimeout( function(){  $('.tab3').click(); }  , .10000 );
            });

            $('.finish_img').click(function(){
                var img_attr = $(this).attr('img_cls');
                $('.'+img_attr).removeClass('img_act');
                $(this).addClass('img_act');
            });

         });
      </script>
      <script>
         $(document).ready(function(){
         	$('#print_btn').click({
         		//$('#invoice_print').print();
         	});
         	//$('#invoice_print').print();
         });

         function print_invoice(el){
             var restorepage = document.body.innerHTML;
             var printcontent = document.getElementById(el).innerHTML;
             document.body.innerHTML = printcontent;
             window.print();
             document.body.innerHTML = restorepage;
         }
      </script>
   </body>
</html>
