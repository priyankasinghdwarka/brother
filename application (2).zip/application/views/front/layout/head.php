<meta charset="utf-8">
<meta name="author" content="">
<meta name="description" content="">
<meta name="keywords" content="">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Title -->
<title>Friedman Brothers:: Home</title>
<!-- Plugin-CSS -->
<link rel="stylesheet" href="<?php echo base_url('assets/front/'); ?>css/bootstrap.min.css" type="text/css"/>
<link rel="stylesheet" href="<?php echo base_url('assets/front/'); ?>css/owl.carousel.min.css" type="text/css"/>
<link rel="stylesheet" href="<?php echo base_url('assets/front/'); ?>css/font-awesome.css" type="text/css"/>
<!-- Main-Stylesheets -->
<link rel="stylesheet" href="<?php echo base_url('assets/front/'); ?>css/style.css" type="text/css"/>
<link rel="stylesheet" href="<?php echo base_url('assets/front/'); ?>css/responsive.css" type="text/css"/>
